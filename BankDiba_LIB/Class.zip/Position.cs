﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using MySql.Data.MySqlClient;
namespace BankDiba_LIB
{
    public class Position
    {
        private int id;
        private string nama;
        private string keterangan;

        #region Constructors
        public Position(int id, string nama, string keterangan)
        {
            Id = id;
            Nama = nama;
            Keterangan = keterangan;
        }
        #endregion

        #region Properties
        public int Id { get => id; set => id = value; }
        public string Nama { get => nama; set => nama = value; }
        public string Keterangan { get => keterangan; set => keterangan = value; }
        #endregion

        #region Methods
        public static List<Position> BacaData(string kriteria, string nilai)
        {
            string sql = "";
            if(kriteria == "")
            {
                sql = "select * from Position";
            }
            else
            {
                sql = "select * from position where " + kriteria + " like '%" + nilai + "%'";
            }
            MySqlDataReader hasil = Koneksi.JalankanPerintahQuery(sql);
            List<Position> listPosition = new List<Position>();
            while (hasil.Read() == true)
            {
                Position p = new Position(hasil.GetInt16(0), hasil.GetString(1), hasil.GetString(2));
                listPosition.Add(p);
            }
            return listPosition;
        }

        public static bool TambahData(Position p)
        {
            string sql = "insert into position(nama, keterangan) values('" + p.Nama + "','" + p.Keterangan + "')";
            int hasil = Koneksi.JalankanPerintahDML(sql);
            if (hasil >= 1) return true;
            return false;
        }
        public static bool HapusData(Position p)
        {
            string sql = "delete from pengguna where id = '" + p.Id + "'";
            int hasil = Koneksi.JalankanPerintahDML(sql);
            if (hasil >= 1) return true;
            return false;
        }
        public static bool UbahData(Position p)
        {
            string sql = "Update position set nama = '" + p.Nama + "', keterangan = '" + p.Keterangan + "' where id ='" + p.Id + "'";
            int hasil = Koneksi.JalankanPerintahDML(sql);
            if (hasil >= 1) return true;
            return false;
        }
        #endregion
    }
}
