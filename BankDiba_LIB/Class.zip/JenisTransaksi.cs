﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using MySql.Data.MySqlClient;

namespace BankDiba_LIB
{
    public class JenisTransaksi
    {
        private int id;
        private string kode;
        private string nama;

        public JenisTransaksi(int id, string kode, string nama)
        {
            Id = id;
            Kode = kode;
            Nama = nama;
        }

        public int Id { get => id; set => id = value; }
        public string Kode { get => kode; set => kode = value; }
        public string Nama { get => nama; set => nama = value; }

        public static List<JenisTransaksi> BacaData(string kriteria, string nilai)
        {
            string sql = "";
            if (kriteria == "")
            {
                sql = "select * from jenisTransaksi";
            }
            else
            {
                sql = "select * from jenisTransaksi where " + kriteria + " = '" + nilai + "'";
            }
            MySqlDataReader hasil = Koneksi.JalankanPerintahQuery(sql);
            List<JenisTransaksi> listJenis = new List<JenisTransaksi>();
            while (hasil.Read())
            {
                JenisTransaksi j = new JenisTransaksi(hasil.GetInt16(0), hasil.GetString(1), hasil.GetString(2));
                listJenis.Add(j);
            }
            return listJenis;
        }

        public static bool TambahData(JenisTransaksi j)
        {
            string sql = "insert into JenisTransaksi(kode, nama) values('" + j.Kode + "','" + j.Nama + "')";
            int hasil = Koneksi.JalankanPerintahDML(sql);
            if (hasil >= 1) return true;
            return false;
        }
        public static bool HapusData(JenisTransaksi j)
        {
            string sql = "delete from pengguna where id = '" + j.Id + "'";
            int hasil = Koneksi.JalankanPerintahDML(sql);
            if (hasil >= 1) return true;
            return false;
        }
        public static bool UbahData(JenisTransaksi j)
        {
            string sql = "Update position set kode = " + j.Kode + ", nama = '" + j.Nama + "' where id = '" + j.Id + "'";
            int hasil = Koneksi.JalankanPerintahDML(sql);
            if (hasil >= 1) return true;
            return false;
        }
    }
}
