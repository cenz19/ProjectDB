﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using MySql.Data.MySqlClient;
namespace BankDiba_LIB
{
    public class Pengguna
    {
        private string nik;
        private string namaDepan;
        private string namaKeluarga;
        private string alamat;
        private string email;
        private string noTelepon;
        private string password;
        private string pin;
        private DateTime tglBuat;
        private DateTime tglPerubahan;

        public Pengguna(string nik, string namaDepan, string namaKeluarga,
            string alamat, string email, string noTelepon, string password, string pin, DateTime tglBuat)
        {
            Nik = nik;
            NamaDepan = namaDepan;
            NamaKeluarga = namaKeluarga;
            Alamat = alamat;
            Email = email;
            NoTelepon = noTelepon;
            Password = password;
            Pin = pin;
            TglBuat = DateTime.Now;
            TglPerubahan = DateTime.Now;
        }

        public string Nik { get => nik; set => nik = value; }
        public string NamaDepan { get => namaDepan; set => namaDepan = value; }
        public string NamaKeluarga { get => namaKeluarga; set => namaKeluarga = value; }
        public string Alamat { get => alamat; set => alamat = value; }
        public string Email { get => email; set => email = value; }
        public string NoTelepon { get => noTelepon; set => noTelepon = value; }
        public string Password { get => password; set => password = value; }
        public string Pin { get => pin; set => pin = value; }
        public DateTime TglBuat { get => tglBuat; set => tglBuat = value; }
        public DateTime TglPerubahan { get => tglPerubahan; set => tglPerubahan = value; }

        public static List<Pengguna> BacaData(string kriteria, string nilai)
        {
            string sql = "";
            if(kriteria == "")
            {
                sql = "select * from pengguna";
            }
            else
            {
                sql = "select * from pengguna where " + kriteria + " like %'" + nilai + "'";
            }

            MySqlDataReader hasil = Koneksi.JalankanPerintahQuery(sql);
            List<Pengguna> listPengguna = new List<Pengguna>();

            while (hasil.Read())
            {
                Pengguna p = new Pengguna(hasil.GetString(0), hasil.GetString(1), hasil.GetString(2), hasil.GetString(3), hasil.GetString(4), hasil.GetString(5), hasil.GetString(6), hasil.GetString(7), hasil.GetDateTime(8));
                listPengguna.Add(p);
            }
            return listPengguna;
        }

        public static bool TambahData(Pengguna p)
        {
            string sql = "insert into pengguna(nama_depan, nama_keluarga, alamat, email, no_telpon, password, pin, tgl_buat, tgl_perubahan)" +
                "values('" + p.NamaDepan + "','" + p.NamaKeluarga + "','" + p.Alamat + "','" + p.Email + "','" + p.NoTelepon +
                "', SHA2('" + p.Password + "', 512), SHA2('" + p.Pin + "', 512),'" + p.TglBuat.ToString("yyyy-MM-dd HH:mm:ss") + "','" + p.TglPerubahan.ToString("yyyy-MM-dd HH:mm:ss") + "')";
            int hasil = Koneksi.JalankanPerintahDML(sql);
            if (hasil >= 1) return true;
            return false;
        }

        public static bool DeleteData(Pengguna p)
        {
            string sql = "delete from pengguna where nik = '" +  p.Nik + "'";
            int hasil = Koneksi.JalankanPerintahDML(sql);
            if (hasil >= 1) return true;
            return false;
        }

        public static bool UbahEmail(Pengguna p, string emailBaru)
        {
            string sql = "update pengguna set email = '" + emailBaru + "',tgl_perubahan = '" + DateTime.Now.ToString("yyyy-MM-dd HH:mm:ss") + "' where nik = '" + p.Nik + "'";
            int hasil = Koneksi.JalankanPerintahDML(sql);
            if (hasil >= 1) return true;
            return false;
        }

        public static bool UbahPin(Pengguna p, string pinBaru)
        {
            string sql = "update pengguna set pin = SHA2('" + pinBaru + "', 512), tgl_perubahan = '" + DateTime.Now.ToString("yyyy-MM-dd HH:mm:ss") + "where nik = '" + p.Nik + "'";
            int hasil = Koneksi.JalankanPerintahDML(sql);
            if (hasil >= 1) return true;
            return false;
        }

        public static bool UbahPassword(Pengguna p,string passwordBaru)
        {
            string sql = "update pengguna set password = SHA2('" + passwordBaru + "', 512),tgl_perubahan = '" + DateTime.Now.ToString("yyyy-MM-dd HH:mm:ss") + "where nik = '" + p.Nik + "'";
            int hasil = Koneksi.JalankanPerintahDML(sql);
            if (hasil >= 1) return true;
            return false;
        }
        public static Pengguna CekLogin(string username, string password)
        {
            string sql = "";
            sql = "select * from pengguna " +
                " where nama_depan='" + username + "' AND Password ='" + password + "'";
            MySqlDataReader hasil = Koneksi.JalankanPerintahQuery(sql);

            while (hasil.Read() == true)
            {
                Pengguna p = new Pengguna(hasil.GetString(0), hasil.GetString(1), hasil.GetString(2), hasil.GetString(3), hasil.GetString(4), hasil.GetString(5), hasil.GetString(6), hasil.GetString(7), hasil.GetDateTime(8));
                return p;
            }
            return null;
        }
    }
}
